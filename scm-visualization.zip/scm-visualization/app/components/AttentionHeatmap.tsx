import { motion } from 'motion/react';

interface AttentionHeatmapProps {
  weights: number[][];
  tokens: string[];
}

export function AttentionHeatmap({ weights, tokens }: AttentionHeatmapProps) {
  return (
    <div className="flex flex-col items-center gap-3">
      <div className="text-sm font-medium text-gray-700">Attention Weights (Softmax)</div>
      <div className="inline-flex flex-col gap-2 p-4 bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="flex gap-2 ml-16">
          {tokens.map((token, i) => (
            <div key={i} className="w-16 text-xs text-center font-medium text-gray-600">
              {token}
            </div>
          ))}
        </div>
        {weights.map((row, i) => (
          <div key={i} className="flex items-center gap-2">
            <div className="w-14 text-xs text-right font-medium text-gray-600">
              {tokens[i]}
            </div>
            <div className="flex gap-1">
              {row.map((weight, j) => (
                <motion.div
                  key={j}
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: (i * row.length + j) * 0.03 }}
                  className="w-16 h-10 flex items-center justify-center rounded relative group"
                  style={{
                    backgroundColor: `rgba(168, 85, 247, ${weight})`,
                  }}
                >
                  <span className="text-xs font-mono text-white drop-shadow">
                    {weight.toFixed(2)}
                  </span>
                  <div className="absolute bottom-full mb-2 hidden group-hover:block bg-gray-900 text-white text-xs rounded py-1 px-2 whitespace-nowrap z-10">
                    {tokens[i]} → {tokens[j]}: {(weight * 100).toFixed(1)}%
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div className="text-xs text-gray-500 max-w-md text-center">
        Each row shows how much each token attends to other tokens
      </div>
    </div>
  );
}
