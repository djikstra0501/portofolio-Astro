import { useState } from 'react';
import { motion } from 'motion/react';
import { Matrix } from './Matrix';
import { AttentionHeatmap } from './AttentionHeatmap';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Slider } from './ui/slider';
import { ArrowRight, Brain, Sparkles } from 'lucide-react';

export function AttentionVisualization() {
  const [sequenceLength, setSequenceLength] = useState(4);
  const [temperature, setTemperature] = useState(1.0);
  const [step, setStep] = useState(0);

  const tokens = ['The', 'cat', 'sat', 'down'].slice(0, sequenceLength);
  
  // Generate random but consistent matrices
  const generateMatrix = (rows: number, cols: number, seed: number) => {
    const matrix: number[][] = [];
    for (let i = 0; i < rows; i++) {
      const row: number[] = [];
      for (let j = 0; j < cols; j++) {
        // Pseudo-random generation
        const val = Math.sin(seed + i * 10 + j * 100) * 2;
        row.push(val);
      }
      matrix.push(row);
    }
    return matrix;
  };

  const Q = generateMatrix(sequenceLength, 3, 1);
  const K = generateMatrix(sequenceLength, 3, 2);
  const V = generateMatrix(sequenceLength, 3, 3);

  // Calculate attention scores: Q * K^T
  const scores: number[][] = [];
  for (let i = 0; i < Q.length; i++) {
    const row: number[] = [];
    for (let j = 0; j < K.length; j++) {
      let sum = 0;
      for (let k = 0; k < Q[i].length; k++) {
        sum += Q[i][k] * K[j][k];
      }
      row.push(sum / Math.sqrt(3)); // Scaled dot-product
    }
    scores.push(row);
  }

  // Apply softmax
  const softmax = (arr: number[]) => {
    const maxVal = Math.max(...arr);
    const exps = arr.map(x => Math.exp((x - maxVal) / temperature));
    const sumExps = exps.reduce((a, b) => a + b, 0);
    return exps.map(x => x / sumExps);
  };

  const attentionWeights = scores.map(row => softmax(row));

  // Calculate output: attention_weights * V
  const output: number[][] = [];
  for (let i = 0; i < attentionWeights.length; i++) {
    const row: number[] = [];
    for (let j = 0; j < V[0].length; j++) {
      let sum = 0;
      for (let k = 0; k < V.length; k++) {
        sum += attentionWeights[i][k] * V[k][j];
      }
      row.push(sum);
    }
    output.push(row);
  }

  const steps = [
    { title: 'Input Tokens', description: 'Token embeddings from the input sequence' },
    { title: 'Linear Projections', description: 'Transform inputs into Query, Key, and Value matrices' },
    { title: 'Attention Scores', description: 'Calculate similarity: Q × Kᵀ / √d_k' },
    { title: 'Attention Weights', description: 'Apply softmax to get probability distribution' },
    { title: 'Weighted Sum', description: 'Compute final output: Attention × V' }
  ];

  return (
    <div className="w-full max-w-7xl mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <Brain className="w-10 h-10 text-purple-600" />
          <h1 className="text-4xl font-bold text-gray-900">Attention Mechanism</h1>
        </div>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Interactive visualization of the self-attention mechanism used in Transformer networks
        </p>
      </div>

      {/* Controls */}
      <Card className="p-6 space-y-6">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-gray-700">Sequence Length: {sequenceLength}</label>
            <Slider
              value={[sequenceLength]}
              onValueChange={(val) => setSequenceLength(val[0])}
              min={2}
              max={4}
              step={1}
              className="w-48"
            />
          </div>
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-gray-700">Temperature: {temperature.toFixed(1)}</label>
            <Slider
              value={[temperature * 10]}
              onValueChange={(val) => setTemperature(val[0] / 10)}
              min={1}
              max={30}
              step={1}
              className="w-48"
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="text-sm font-medium text-gray-700">Step:</div>
          <div className="flex gap-2 flex-wrap">
            {steps.map((s, i) => (
              <Button
                key={i}
                onClick={() => setStep(i)}
                variant={step === i ? 'default' : 'outline'}
                size="sm"
              >
                {i + 1}. {s.title}
              </Button>
            ))}
          </div>
        </div>
      </Card>

      {/* Current Step Display */}
      <motion.div
        key={step}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 rounded-full">
          <Sparkles className="w-4 h-4 text-purple-600" />
          <span className="font-medium text-purple-900">{steps[step].title}</span>
        </div>
        <p className="mt-2 text-gray-600">{steps[step].description}</p>
      </motion.div>

      {/* Visualization Area */}
      <div className="space-y-8">
        {step === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex justify-center"
          >
            <Card className="p-6">
              <div className="flex gap-4 items-center">
                {tokens.map((token, i) => (
                  <div key={i} className="flex flex-col items-center gap-2">
                    <div className="w-20 h-20 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-medium shadow-lg">
                      {token}
                    </div>
                    <div className="text-xs text-gray-500">Token {i + 1}</div>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>
        )}

        {step === 1 && (
          <div className="flex flex-wrap justify-center gap-8">
            <Matrix data={Q} label="Query (Q)" />
            <Matrix data={K} label="Key (K)" />
            <Matrix data={V} label="Value (V)" />
          </div>
        )}

        {step === 2 && (
          <div className="flex flex-col items-center gap-6">
            <div className="flex items-center gap-4">
              <Matrix data={Q} label="Q" small />
              <span className="text-2xl">×</span>
              <Matrix data={K[0].map((_, colIndex) => K.map(row => row[colIndex]))} label="Kᵀ" small />
              <span className="text-2xl">=</span>
              <Matrix data={scores} label="Scores" small />
            </div>
            <div className="text-sm text-gray-600 bg-gray-50 px-4 py-2 rounded">
              Formula: Score = Q × Kᵀ / √d_k
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="flex justify-center">
            <AttentionHeatmap weights={attentionWeights} tokens={tokens} />
          </div>
        )}

        {step === 4 && (
          <div className="flex flex-col items-center gap-6">
            <div className="flex items-center gap-4 flex-wrap justify-center">
              <AttentionHeatmap weights={attentionWeights} tokens={tokens} />
              <div className="flex flex-col items-center gap-4">
                <ArrowRight className="w-8 h-8 text-gray-400" />
                <span className="text-2xl">×</span>
                <ArrowRight className="w-8 h-8 text-gray-400" />
              </div>
              <Matrix data={V} label="V" small />
              <span className="text-2xl">=</span>
              <Matrix data={output} label="Output" />
            </div>
            <div className="text-sm text-gray-600 bg-gray-50 px-4 py-2 rounded max-w-md text-center">
              The output is a weighted sum of the value vectors, where weights are determined by attention scores
            </div>
          </div>
        )}
      </div>

      {/* Formula Reference */}
      <Card className="p-6 bg-gray-50">
        <h3 className="font-semibold text-gray-900 mb-3">Attention Formula</h3>
        <div className="font-mono text-sm bg-white p-4 rounded border border-gray-200 overflow-x-auto">
          Attention(Q, K, V) = softmax(Q × Kᵀ / √d_k) × V
        </div>
        <div className="mt-4 text-sm text-gray-600 space-y-1">
          <p><strong>Q</strong> (Query): What we're looking for</p>
          <p><strong>K</strong> (Key): What we have to offer</p>
          <p><strong>V</strong> (Value): The actual information to retrieve</p>
          <p><strong>d_k</strong>: Dimension of the key vectors (scaling factor)</p>
        </div>
      </Card>
    </div>
  );
}
