import { motion } from 'motion/react';

interface MatrixProps {
  data: number[][];
  label: string;
  highlight?: { row?: number; col?: number };
  small?: boolean;
}

export function Matrix({ data, label, highlight, small = false }: MatrixProps) {
  const maxVal = Math.max(...data.flat().map(Math.abs));
  
  const getColor = (val: number) => {
    const intensity = Math.abs(val) / maxVal;
    if (val > 0) {
      return `rgba(59, 130, 246, ${intensity * 0.8})`;
    } else {
      return `rgba(239, 68, 68, ${intensity * 0.8})`;
    }
  };

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="text-sm font-medium text-gray-700">{label}</div>
      <div className="inline-flex flex-col gap-1 p-3 bg-white rounded-lg border border-gray-200 shadow-sm">
        {data.map((row, i) => (
          <div key={i} className="flex gap-1">
            {row.map((val, j) => (
              <motion.div
                key={j}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: (i * row.length + j) * 0.02 }}
                className={`
                  ${small ? 'w-8 h-8 text-xs' : 'w-12 h-12 text-sm'}
                  flex items-center justify-center rounded
                  ${highlight?.row === i || highlight?.col === j ? 'ring-2 ring-yellow-400' : ''}
                `}
                style={{ backgroundColor: getColor(val) }}
              >
                <span className="font-mono text-white drop-shadow">
                  {val.toFixed(1)}
                </span>
              </motion.div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
