import { AttentionVisualization } from './components/AttentionVisualization';

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <AttentionVisualization />
    </div>
  );
}
